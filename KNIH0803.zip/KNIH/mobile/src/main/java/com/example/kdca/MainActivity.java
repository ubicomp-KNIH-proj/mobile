package com.example.kdca;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@SuppressWarnings("ALL")
public class MainActivity extends Activity implements View.OnClickListener{

    private final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STROAGE = 1001;
    private PermissionSupport permission;
    static final int ALARM_REQ_CODE = 100;

    private PowerManager.WakeLock wl;

    TextView textView;
    Button button;
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    EditText SIDText;

    // Lee.S for ACP
    EditText ACPText;
    boolean SID_ACP_flag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        permissionCheck();

        // Lee.S
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        textView = (TextView) findViewById(R.id.fileContents);
        SIDText = (EditText) findViewById(R.id.editTextNumber);

        // Lee.S for ACP
        ACPText = (EditText) findViewById(R.id.editTextNumber3);

        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(this);
        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(this);
        button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(this);
        button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(this);


        // Lee.S for ACP
        try {
            String SID_File = readFile_SID();
            EditText editText_SID = (EditText) findViewById(R.id.editTextNumber);
            String SID_num = editText_SID.getText().toString();

            String ACP_File = readFile_ACP();
            EditText editText_ACP = (EditText) findViewById(R.id.editTextNumber3);
            String ACP_num = editText_ACP.getText().toString();

            System.out.println(SID_num+ACP_num);

            new Thread(() -> {
                try {
                    if(checkACP.check(SID_num, ACP_num)) {
                        // ACP Authentication successful
                        textView.setText("인증 성공");
                        writeFile_SID(SID_num);
                        writeFile_ACP(ACP_num);
                        button1.setBackgroundColor(Color.GREEN);
                        button1.setTextColor(Color.BLACK);
                        textView.setTextColor(Color.GREEN);
                    }
                    else {
                        // ACP Authentication failed
                        textView.setText("인증 실패");
                        textView.setTextColor(Color.RED);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Lee.S for ACP
        SIDText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.length() > 2) {
                    SID_ACP_flag = true;
                    ACPText.requestFocus();
                } else {
                    SID_ACP_flag = false;
                }
            }
        });

        // Lee.S for ACP
        ACPText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.length() > 6 & SID_ACP_flag) {
                    button1.setClickable(true);
                    button1.setBackgroundColor(Color.BLUE);
                    button1.setTextColor(Color.WHITE);
                    button1.setText("등록하기");
                } else {
                    button1.setClickable(false);
                    button1.setBackgroundColor(Color.GRAY);
                    button1.setText("등록하기");
                }
            }
        });

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "MainActivity");

        if(!foregroundServiceRunning()) {
            Intent serviceIntent = new Intent(this, MyForegroundService.class);
            startForegroundService(serviceIntent);
        }

        AlarmManager alarmManager =(AlarmManager) getSystemService(ALARM_SERVICE);

        int time = 1;
        long triggerTime = System.currentTimeMillis()+ (time*1000);

        Intent iBroadCast = new Intent(MainActivity.this,MyAlarm.class);
        PendingIntent pi = null;
        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.S){
            pi = PendingIntent.getBroadcast(MainActivity.this,ALARM_REQ_CODE,iBroadCast,PendingIntent.FLAG_MUTABLE);
        }else {
            pi = PendingIntent.getBroadcast(MainActivity.this,ALARM_REQ_CODE,iBroadCast,PendingIntent.FLAG_UPDATE_CURRENT);
        }

        //alarmManager.set(AlarmManager.RTC_WAKEUP,triggerTime,pi);
        //setting the repeating alarm that will be fired every day
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, triggerTime, 1000, pi);

    }

    private void permissionCheck(){
        // sdk 23버전 이하 버전에서는 permission이 필요하지 않음
        if(Build.VERSION.SDK_INT >= 23){

            // 클래스 객체 생성
            permission =  new PermissionSupport(this, this);

            // 권한 체크한 후에 리턴이 false일 경우 권한 요청을 해준다.
            if(!permission.checkPermission()){
                permission.requestPermission();
            }
        }
    }

    // Lee.S for ACP
    public void writeFile_SID(String num) throws IOException {
        BufferedOutputStream bs = null;

        File file = new File("/storage/self/primary/Download/KNIH/SID.txt");

        if (!file.exists()) {
            file.createNewFile();
            System.out.println(" SID - file --------- 파일 생성 완료 ---------");
        }

        FileWriter fw = null ;
        String SID = num ;

        System.out.println("[SET SID:\t" + SID + "]");

        try {
            // open file.
            fw = new FileWriter(file) ;

            // write file.
            fw.write("S"+SID) ;

        } catch (Exception e) {
            e.printStackTrace() ;
        }

        // close file.
        if (fw != null) {
            // catch Exception here or throw.
            try {
                fw.close() ;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // Lee.S for ACP
    public void writeFile_ACP(String num) throws IOException {
        BufferedOutputStream bs = null;

        File file = new File("/storage/self/primary/Download/KNIH/ACP.txt");

        if (!file.exists()) {
            file.createNewFile();
            System.out.println(" ACP - file --------- 파일 생성 완료 ---------");
        }

        FileWriter fw = null ;
        String ACP = num ;

        System.out.println("[SET SID:\t" + ACP + "]");

        try {
            // open file.
            fw = new FileWriter(file) ;

            // write file.
            fw.write(ACP) ;

        } catch (Exception e) {
            e.printStackTrace() ;
        }

        // close file.
        if (fw != null) {
            // catch Exception here or throw.
            try {
                fw.close() ;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    // Lee.S for ACP
    public  String readFile_SID() throws IOException {
        String mkdir_PATH = "/storage/self/primary/Download/KNIH/";
        File dir = new File(mkdir_PATH);
        try {
            if (!dir.exists()) {
                dir.mkdirs();
            }

        }catch (Exception e) {
            e.printStackTrace();
        }

        File file = new File("/storage/self/primary/Download/KNIH/SID.txt");

        if (!file.exists()) {
            BufferedOutputStream bs = null;

            file.createNewFile();
            FileWriter fw = null ;
            String SID = "S1000" ;
//            System.out.println("[SET SID:\t" + SID + "]");

            try {
                // open file.
                fw = new FileWriter(file) ;

                // write file.
                fw.write(SID) ;

            } catch (Exception e) {
                e.printStackTrace() ;
            }

            // close file.
            if (fw != null) {
                // catch Exception here or throw.
                try {
                    fw.close() ;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        FileReader fr = null;
        char[] cbuf = new char[512];
        int size = 0;
        String data = "";

        try {
            // open file.
            fr = new FileReader(file);

            // read file.
            while ((size = fr.read(cbuf)) != -1) {
                // TODO : use data
//                System.out.println("read size : " + size);
                for (int i = 0; i < size; i++) {
//                    System.out.println("data : " + cbuf[i]);
                    data += cbuf[i];
                }
            }

            fr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }
//    public String readFile_SID() throws IOException {
//        File file = new File("/storage/self/primary/Download/KNIH/SID.txt");
//        FileReader fr = null;
//        char[] cbuf = new char[512];
//        int size = 0;
//        String data ="";
//
//        try {
//            // open file.
//            fr = new FileReader(file);
//
//            // read file.
//            while ((size = fr.read(cbuf)) != -1) {
//                // TODO : use data
//                System.out.println("read size : " + size);
//                for (int i = 0; i < size; i++) {
//                    System.out.println("data : " + cbuf[i]);
//                    data += cbuf[i];
//                }
//            }
//
//            fr.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        System.out.println("\n==============================\n"+data);
//        return data;
//    }

    // Lee.S for ACP
    public String readFile_ACP() throws IOException {
        String mkdir_PATH = "/storage/self/primary/Download/KNIH/";
        File dir = new File(mkdir_PATH);
        try {
            if (!dir.exists()) {
                dir.mkdirs();
            }

        }catch (Exception e) {
            e.printStackTrace();
        }

        File file = new File("/storage/self/primary/Download/KNIH/ACP.txt");

        if (!file.exists()) {
            BufferedOutputStream bs = null;

            file.createNewFile();
            FileWriter fw = null ;
            String ACP = "ubicomp" ;

            try {
                // open file.
                fw = new FileWriter(file) ;

                // write file.
                fw.write(ACP) ;

            } catch (Exception e) {
                e.printStackTrace() ;
            }

            // close file.
            if (fw != null) {
                // catch Exception here or throw.
                try {
                    fw.close() ;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        FileReader fr = null;
        char[] cbuf = new char[512];
        int size = 0;
        String data = "";

        try {
            // open file.
            fr = new FileReader(file);

            // read file.
            while ((size = fr.read(cbuf)) != -1) {
                // TODO : use data
//                System.out.println("read size : " + size);
                for (int i = 0; i < size; i++) {
//                    System.out.println("data : " + cbuf[i]);
                    data += cbuf[i];
                }
            }

            fr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }
//    public String readFile_ACP() throws IOException {
//        File file = new File("/storage/self/primary/Download/KNIH/ACP.txt");
//        FileReader fr = null;
//        char[] cbuf = new char[512];
//        int size = 0;
//        String data ="";
//
//        try {
//            // open file.
//            fr = new FileReader(file);
//
//            // read file.
//            while ((size = fr.read(cbuf)) != -1) {
//                // TODO : use data
//                System.out.println("read size : " + size);
//                for (int i = 0; i < size; i++) {
//                    System.out.println("data : " + cbuf[i]);
//                    data += cbuf[i];
//                }
//            }
//
//            fr.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        System.out.println("\n==============================\n"+data);
//        return data;
//    }

    // Lee.S
    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(this);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    // Lee.S
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        hideKeyboard();
        return super.dispatchTouchEvent(ev);
    }

    public boolean foregroundServiceRunning(){
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for(ActivityManager.RunningServiceInfo service: activityManager.getRunningServices(Integer.MAX_VALUE)) {
            if(MyForegroundService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    // Lee.S for ACP
    public void btnClick1(View view) {
        try {
            final InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);

            String SID_File = readFile_SID();
            EditText editText_SID = (EditText) findViewById(R.id.editTextNumber);
            String SID_num = editText_SID.getText().toString();

            String ACP_File = readFile_ACP();
            EditText editText_ACP = (EditText) findViewById(R.id.editTextNumber3);
            String ACP_num = editText_ACP.getText().toString();

            System.out.println("\n\tSID:\t"+SID_num);
            System.out.println("\n\tACP:\t"+ACP_num);

            checkACP checkACP = new checkACP();

            new Thread(() -> {
                try {
                    if(checkACP.check(SID_num, ACP_num)) {
                        // ACP Authentication successful
                        textView.setText("인증 성공");
                        writeFile_SID(SID_num);
                        writeFile_ACP(ACP_num);
                        button1.setBackgroundColor(Color.GREEN);
                        button1.setTextColor(Color.BLACK);
                        textView.setTextColor(Color.GREEN);
                    }
                    else {
                        // ACP Authentication failed
                        textView.setText("인증 실패");
                        textView.setTextColor(Color.RED);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // Lee.S
    @Override
    public void onClick(View view) {
        if(view==button2) {
            new AlertDialog.Builder(this)
                    .setTitle("유의 사항") //팝업창 타이틀바
                    .setMessage("\n" +
                            "[드래그로 내려주세요]\n\n" +
                            "#1. 수면 시 침구 위에 스마트폰을 올려주시기 바랍니다\n" +
                            "(되도록 충전과 동시에 실험을 진행 해 주세요)\n" +
                            "\n" +
                            "#2. 워치와 스마트폰은 항상 같이 있을 수 있도록 해주세요\n" +
                            "(7미터 이내)\n" +
                            "\n" +
                            "#3. 스마트폰 내부 잔여 용량을 5GB 이상으로 유지해주세요\n" +
                            "\n" +
                            "#4. 진행 중 어떠한 문제가 있다면, \n" +
                            "010-2490-5530으로 연락해주세요\n" +
                            "\n" +
                            "#5. 이 앱은 와이파이, 셀룰러 네트워크가 연결된 환경에서\n" +
                            "15분마다 센서 데이터를 자동으로 서버에 올립니다\n" +
                            "인터넷 연결을 유지해 주시기 바랍니다\n" +
                            "\n" +
                            "#6. 정보 데이터들은 1일이 지나면,\n" +
                            "다운로드 폴더 아래 KNIH 폴더에\n" +
                            "날짜별로 .tar 파일로 압축이 되어 생성됩니다\n" +
                            "(예시) 오늘이 7월 13일 경우, [KNIH220712.tar]\n" +
                            "\n" +
                            "#7. 설문 조사 후 업로드 버튼을 눌러주시고,\n" +
                            "#6번에서 생성된 [tar 파일] 중\n" +
                            "전날 날짜에 해당하는 [tar 파일] 있다면,\n" +
                            "이를 업로드 해 주시면 됩니다\n" +
                            "만일, 해당 파일이 없으면\n" +
                            "서버에 데이터가 잘 올라간 것이기 때문에 상관이 없습니다\n" +
                            "\n" +
                            "#8.백그라운드에서도 앱이 실행되나,\n캐시 클리너 등의 앱으로\n" +
                            "해당 앱을 강제종료시키지 말아주세요")  //팝업창 내용
                    .setNeutralButton("[닫기]",new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dlg, int sumthin) {

                        }
                    })
                    .show();
        }
        if(view==button) {
            new AlertDialog.Builder(this)
                    .setTitle("Precautions") //팝업창 타이틀바
                    .setMessage("\n" +
                            "[Put it down with a drag]\n" +
                            "\n" +
                            "#1. Please put your smartphone on the bed when you sleep\n" +
                            "(If possible, proceed with the experiment at the same time as charging.)\n" +
                            "\n" +
                            "#2. Make sure the watch and smartphone are always together (within 7 meters)\n" +
                            "\n" +
                            "#3. Keep the remaining capacity inside the smartphone above 5GB\n" +
                            "\n" +
                            "#4. If you are experiencing any problems, please call 010-2490-5530\n" +
                            "\n" +
                            "#5. This app automatically uploads sensor data to the server every 15 minutes in an environment with Wi-Fi and cellular networks Please maintain your Internet connection\n" +
                            "\n" +
                            "#6. After 1 day, the information data is in the KNIH folder under the download folder\n" +
                            "Compressed into a .tar file by date\n" +
                            "If today is July 13, [KNIH220712.tar]\n" +
                            "\n" +
                            "#7. Click the upload button after the survey, and if there is a [tar file] that corresponds to the previous day's date among [tar file] generated in #6, you can upload it. If you don't have that file, it doesn't matter because the data is uploaded well to the server\n" +
                            "\n" +
                            "#8.The app runs in the background, so please do not force the app to shut down with an app such as a cache cleaner")  //팝업창 내용
                    .setNeutralButton("[Close]",new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dlg, int sumthin) {

                        }
                    })
                    .show();
        }
        if(view==button3) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://114.71.220.59:2017/register"));
            startActivity(intent);
        }
        if(view==button4) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://114.71.220.59:2017"));
            startActivity(intent);
        }
    }
}
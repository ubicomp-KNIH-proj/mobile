package com.example.kdca;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.wearable.DataApi;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.Wearable;
import com.opencsv.CSVWriter;

import org.apache.commons.lang3.ArrayUtils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.StringJoiner;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@RequiresApi(api = Build.VERSION_CODES.N)
public class MyForegroundService extends Service implements DataApi.DataListener, GoogleApiClient.ConnectionCallbacks,GoogleApiClient.OnConnectionFailedListener, SensorEventListener {
    GoogleApiClient googleApiClient;
    List<String> s_acc = new ArrayList<>();
    List<String> s_gyro = new ArrayList<>();
    List<String> s_hr = new ArrayList<>();
    List<String> s_pre = new ArrayList<>();

    private static final float NS2S = 1.0f / 1000000000.0f;

    // initialization of measuremenet time of all sensors
    int accTimeManager = 0;
    int gyroTimeManager = 0;
    int preTimeManager = 0;
    int lightTimeManager = 0;

    //Sensor measurement current measured value of sensor buffer
    List<Float> PH_acc = new ArrayList<>();
    List<Float> PH_gyro = new ArrayList<>();
    List<Float> PH_pre = new ArrayList<>();
    List<Float> PH_Light = new ArrayList<>();

    // For csv onevsecond buffer of every sensor
    List<Float> PH_acc_csv = new ArrayList<>();
    List<Float> PH_gyro_csv = new ArrayList<>();
    List<Float> PH_pre_csv = new ArrayList<>();
    List<Float> PH_Light_csv = new ArrayList<>();

    //For mobius every 30 min Mobile phone/ android buffer
    List<String> Mobius_PH_acc = new ArrayList<>();
    List<String> Mobius_PH_gyro = new ArrayList<>();
    List<String> Mobius_PH_pre = new ArrayList<>();
    List<String> Mobius_PH_Light = new ArrayList<>();

    //For mobius every 30 min Watch buffer
    List<String> Mobius_wPH_acc = new ArrayList<>();
    List<String> Mobius_wPH_gyro = new ArrayList<>();
    List<String> Mobius_wPH_pre = new ArrayList<>();
    List<String> Mobius_wPH_Hr = new ArrayList<>();

    //Available sensor state
    boolean M_pressure = false;
    boolean M_Accerelometer = false;
    boolean M_Light = false;
    boolean M_Gyroscope = false;

    public MyForegroundService() throws IOException {
    }

    // Subject ID Lee.S for ACP
    public String SID = readFile_SID();

    // ACP Lee.S for ACP
    public String ACP = readFile_ACP();

    // Lee.S for ACP
    public static String readFile_SID() throws IOException {
        String mkdir_PATH = "/storage/self/primary/Download/KNIH/";
        File dir = new File(mkdir_PATH);
        try {
            if (!dir.exists()) {
                dir.mkdirs();
            }

        }catch (Exception e) {
            e.printStackTrace();
        }

        File file = new File("/storage/self/primary/Download/KNIH/SID.txt");

        if (!file.exists()) {
            BufferedOutputStream bs = null;

            file.createNewFile();
            FileWriter fw = null ;
            String SID = "S1000" ;
//            System.out.println("[SET SID:\t" + SID + "]");

            try {
                // open file.
                fw = new FileWriter(file) ;

                // write file.
                fw.write(SID) ;

            } catch (Exception e) {
                e.printStackTrace() ;
            }

            // close file.
            if (fw != null) {
                // catch Exception here or throw.
                try {
                    fw.close() ;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        FileReader fr = null;
        char[] cbuf = new char[512];
        int size = 0;
        String data = "";

        try {
            // open file.
            fr = new FileReader(file);

            // read file.
            while ((size = fr.read(cbuf)) != -1) {
                // TODO : use data
//                System.out.println("read size : " + size);
                for (int i = 0; i < size; i++) {
//                    System.out.println("data : " + cbuf[i]);
                    data += cbuf[i];
                }
            }

            fr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    // Lee.S for ACP
    public static String readFile_ACP() throws IOException {
        String mkdir_PATH = "/storage/self/primary/Download/KNIH/";
        File dir = new File(mkdir_PATH);
        try {
            if (!dir.exists()) {
                dir.mkdirs();
            }

        }catch (Exception e) {
            e.printStackTrace();
        }

        File file = new File("/storage/self/primary/Download/KNIH/ACP.txt");

        if (!file.exists()) {
            BufferedOutputStream bs = null;

            file.createNewFile();
            FileWriter fw = null ;
            String ACP = "S606606" ;

            try {
                // open file.
                fw = new FileWriter(file) ;

                // write file.
                fw.write(ACP) ;

            } catch (Exception e) {
                e.printStackTrace() ;
            }

            // close file.
            if (fw != null) {
                // catch Exception here or throw.
                try {
                    fw.close() ;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        FileReader fr = null;
        char[] cbuf = new char[512];
        int size = 0;
        String data = "";

        try {
            // open file.
            fr = new FileReader(file);

            // read file.
            while ((size = fr.read(cbuf)) != -1) {
                // TODO : use data
//                System.out.println("read size : " + size);
                for (int i = 0; i < size; i++) {
//                    System.out.println("data : " + cbuf[i]);
                    data += cbuf[i];
                }
            }

            fr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        googleApiClient = new GoogleApiClient.Builder(this)
                .addApi(Wearable.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();
        googleApiClient.connect();

        SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null){
            sensorManager.registerListener(MyForegroundService.this, accelerometer, 100000);
            M_Accerelometer = true;
        }

        Sensor mGyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if (mGyro != null){
            sensorManager.registerListener(MyForegroundService.this, mGyro, 100000);
            M_Gyroscope = true;
        }


        Sensor mPressure = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);
        if (mPressure != null){
            sensorManager.registerListener(MyForegroundService.this, mPressure,100000);
            M_pressure = true;
        }
        // 1/ (100,000/1,000,000) SAMPLING RATE 10Hz
        Sensor mLight = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        if (mLight != null){
            sensorManager.registerListener(MyForegroundService.this, mLight, 100000);
            M_Light = true;
        }
        //callTimer();
        callTimer1();

        int TimeForMobius = 1;//minutes

        new Thread(
                () -> {
                    while (true) {
                        Log.e("Service", "KNIH running"+SID);
                        Log.e("Service", "SID:\t "+SID);
                        @SuppressLint("SimpleDateFormat") SimpleDateFormat mFormat1 = new SimpleDateFormat("yyMMdd HH:mm:ss");
                        long mNow1 = System.currentTimeMillis();
                        Date mDate1 = new Date(mNow1);
                        System.out.println("CURRENT TIMESTAMP "+ mFormat1.format(mDate1));

                        try {
                            SendMobius30();
                            Thread.sleep(1000*60*TimeForMobius,1000);

                        } catch (InterruptedException | IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
        ).start();

        final String CHANNELID = "Foreground Service ID";
        NotificationChannel channel = new NotificationChannel( CHANNELID, CHANNELID, NotificationManager.IMPORTANCE_LOW );

        getSystemService(NotificationManager.class).createNotificationChannel(channel);
        Notification.Builder notification = new Notification.Builder(this, CHANNELID)
                .setContentText("KNIH RUNNING " + SID)
                .setContentTitle("Service enabled")
                .setSmallIcon(R.drawable.ic_launcher_background);

        startForeground(1001, notification.build());

        return super.onStartCommand(intent, flags, startId);
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    ///Watch functions to upload data to mobius or IoT server
    public void upload_to_mobius_watch_wAcc(String S_name,String Data) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        MediaType mediaType = MediaType.parse("application/vnd.onem2m-res+json; ty=4");
        RequestBody body1 = RequestBody.create(mediaType, "{\n    \"m2m:cin\": {\n        \"con\": \"" + Data + "\"\n    }\n}");


        Request request1 = new Request.Builder()
                .url("http://114.71.220.59:7579/Mobius/"+SID+"/watch/"+S_name)
                .method("POST", body1)
                .addHeader("Accept", "application/json")
                .addHeader("X-M2M-RI", "12345")
                .addHeader("X-M2M-Origin", ACP)
                .addHeader("Content-Type", "application/vnd.onem2m-res+json; ty=4")
                .build();


        Call call = client.newCall(request1);
        Response response = call.execute();
        Integer responseData1 = 0;
        responseData1 = response.code();
        if (responseData1 != 201 && !Data.contains("None") ){
            String[] results;
            results = Data.split(",");

            List<Float> convertedAcc = new ArrayList<>();

            for (int j = 0; j < results.length; j++) {
                float wewe = Float.parseFloat(results[j]);
                convertedAcc.add(wewe);
            }

            // preparing one sec data
            int fromIndex = 0;
            int toIndex = 32;
            for (int k = 0; k < convertedAcc.size() / 32; k++) {
                List<Float> arrlist2 = convertedAcc.subList(fromIndex, toIndex);
                writeDataToCsv("Watch_Acc", arrlist2);
                convertedAcc.subList(fromIndex, toIndex).clear();
            }

        }
        if (responseData1 == 201){
            float timestamp = System.currentTimeMillis() / 1000L;
            List<Float> Logdata = new ArrayList<>();
            Logdata.addAll(Collections.singletonList((float) responseData1));
            Logdata.addAll(Collections.singleton(timestamp));
            try {
                writeDataToCsv("WACC_Log", Logdata);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Log.d("TEST", "W_ACC RESPONSE MESSAGE : " + responseData1);


    }
    public void upload_to_mobius_watch_wGyr(String S_name,String Data) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        MediaType mediaType = MediaType.parse("application/vnd.onem2m-res+json; ty=4");
        RequestBody body1 = RequestBody.create(mediaType, "{\n    \"m2m:cin\": {\n        \"con\": \"" + Data + "\"\n    }\n}");


        Request request1 = new Request.Builder()
                .url("http://114.71.220.59:7579/Mobius/"+SID+"/watch/"+S_name)
                .method("POST", body1)
                .addHeader("Accept", "application/json")
                .addHeader("X-M2M-RI", "12345")
                .addHeader("X-M2M-Origin", ACP)
                .addHeader("Content-Type", "application/vnd.onem2m-res+json; ty=4")
                .build();


        //client.newCall(request1).enqueue(upload_to_mobiusCallback_wGyr);
        Call call = client.newCall(request1);
        Response response = call.execute();
        Integer responseData1 = 0;
        responseData1 = response.code();
        if (responseData1 != 201 && !Data.contains("None") ){

            String[] results;
            results = Data.split(",");

            List<Float> convertedAcc = new ArrayList<>();

            for (int j = 0; j < results.length; j++) {
                float wewe = Float.parseFloat(results[j]);
                convertedAcc.add(wewe);
            }

            // preparing one sec data
            int fromIndex = 0;
            int toIndex = 32;
            for (int k = 0; k < convertedAcc.size() / 32; k++) {
                List<Float> arrlist2 = convertedAcc.subList(fromIndex, toIndex);
                writeDataToCsv("Watch_Gyro", arrlist2);
                convertedAcc.subList(fromIndex, toIndex).clear();
            }
        }
        if (responseData1 == 201){
            float timestamp = System.currentTimeMillis() / 1000L;
            List<Float> Logdata = new ArrayList<>();
            Logdata.addAll(Collections.singletonList((float) responseData1));
            Logdata.addAll(Collections.singleton(timestamp));
            try {
                writeDataToCsv("WGyro_Log", Logdata);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Log.d("TEST", "W_GYRO RESPONSE MESSAGE : " + responseData1);


    }
    public void upload_to_mobius_watch_wPre(String S_name,String Data) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        MediaType mediaType = MediaType.parse("application/vnd.onem2m-res+json; ty=4");
        RequestBody body1 = RequestBody.create(mediaType, "{\n    \"m2m:cin\": {\n        \"con\": \"" + Data + "\"\n    }\n}");


        Request request1 = new Request.Builder()
                .url("http://114.71.220.59:7579/Mobius/"+SID+"/watch/"+S_name)
                .method("POST", body1)
                .addHeader("Accept", "application/json")
                .addHeader("X-M2M-RI", "12345")
                .addHeader("X-M2M-Origin", ACP)
                .addHeader("Content-Type", "application/vnd.onem2m-res+json; ty=4")
                .build();


        //client.newCall(request1).enqueue(upload_to_mobiusCallback_wPre);
        Call call = client.newCall(request1);
        Response response = call.execute();
        Integer responseData1 = 0;
        responseData1 = response.code();
        if (responseData1 != 201 && !Data.contains("None")){
                String[] results;
                results = Data.split(",");

                List<Float> convertedAcc = new ArrayList<>();

                for (int j = 0; j < results.length; j++) {
                    float wewe = Float.parseFloat(results[j]);
                    convertedAcc.add(wewe);
                }

                // preparing one sec data
                int fromIndex = 0;
                int toIndex = 3;
                for (int k = 0; k < convertedAcc.size() / 3; k++) {
                    List<Float> arrlist2 = convertedAcc.subList(fromIndex, toIndex);
                    writeDataToCsv("Watch_Pre", arrlist2);
                    convertedAcc.subList(fromIndex, toIndex).clear();
                }

        }
        if (responseData1 == 201){
            float timestamp = System.currentTimeMillis() / 1000L;
            List<Float> Logdata = new ArrayList<>();
            Logdata.addAll(Collections.singletonList((float) responseData1));
            Logdata.addAll(Collections.singleton(timestamp));
            try {
                writeDataToCsv("WPRE_LOG", Logdata);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Log.d("TEST", "PRE RESPONSE MESSAGE : " + responseData1);


    }
    public void upload_to_mobius_watch_wHR(String S_name,String Data) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        MediaType mediaType = MediaType.parse("application/vnd.onem2m-res+json; ty=4");
        RequestBody body1 = RequestBody.create(mediaType, "{\n    \"m2m:cin\": {\n        \"con\": \"" + Data + "\"\n    }\n}");


        Request request1 = new Request.Builder()
                .url("http://114.71.220.59:7579/Mobius/"+SID+"/watch/"+S_name)
                .method("POST", body1)
                .addHeader("Accept", "application/json")
                .addHeader("X-M2M-RI", "12345")
                .addHeader("X-M2M-Origin", ACP)
                .addHeader("Content-Type", "application/vnd.onem2m-res+json; ty=4")
                .build();


        Call call = client.newCall(request1);
        Response response = call.execute();
        Integer responseData1 = 0;
        responseData1 = response.code();
        if (responseData1 != 201 && !Data.contains("None")){
            String[] results;
            results = Data.split(",");

            List<Float> convertedAcc = new ArrayList<>();

            for (int j = 0; j < results.length; j++) {
                float wewe = Float.parseFloat(results[j]);
                convertedAcc.add(wewe);
            }

            // preparing one sec data
            int fromIndex = 0;
            int toIndex = 3;
            for (int k = 0; k < convertedAcc.size() / 3; k++) {
                List<Float> arrlist2 = convertedAcc.subList(fromIndex, toIndex);
                writeDataToCsv("Watch_Hr", arrlist2);
                Compress_Folder();
                convertedAcc.subList(fromIndex, toIndex).clear();
            }
        }
        if (responseData1 == 201){
            float timestamp = System.currentTimeMillis() / 1000L;
            List<Float> Logdata = new ArrayList<>();
            Logdata.addAll(Collections.singletonList((float) responseData1));
            Logdata.addAll(Collections.singleton(timestamp));
            try {
                writeDataToCsv("WHR_Log", Logdata);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Log.d("TEST", "HR RESPONSE MESSAGE : " + responseData1);

    }

    // Lee.S
    public void Delete(String DATE) {
        String path = "/storage/self/primary/Download/KNIH/KNIH_" + DATE;
        File folder = new File(path);

        try {
            while(folder.exists()) {
                File[] folder_list = folder.listFiles();

                for (int j = 0; j < folder_list.length; j++) {
                    folder_list[j].delete();
                    System.out.println(DATE + "\tCSV file deleted successfully");
                }

                if(folder_list.length == 0 && folder.isDirectory()){
                    folder.delete();
                    System.out.println(DATE + "\tFolder deleted successfully");
                }
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    // Lee.S
    public String get_Yesterday(){
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat SDF = new SimpleDateFormat("yyMMdd");

        String chkDate = SDF.format(calendar.getTime());
//        System.out.println("Today : " + chkDate);

        calendar.add(Calendar.DATE, -1);
        chkDate = SDF.format(calendar.getTime());
//        System.out.println("Yesterday : " + chkDate);

        return chkDate;
    }

    // Lee.S
    // 1. Check for folders the day before
    // 2. Compress and delete the folder and csv, if any
    public void Compress_Folder() {
        String yesterday = get_Yesterday();

        System.out.println("[COMPRESS]");
        System.out.println("Yesterday: " + yesterday);

        String yesterday_Route = "/storage/self/primary/Download/KNIH/KNIH_" + yesterday;

        File file = new File(yesterday_Route);

        if(file.exists()){
            System.out.println("Folder Exists");

            // (.zip or .tar)
            String type = ".tar";

            String toZipPath = yesterday_Route; // Folder path to compress
            String unZipPath = "/storage/self/primary/Download/KNIH/";  // Path to store compressed files
            String unZipFile = "KNIH_" + yesterday;   // Compressed file name

            // Compression
            try {
                System.out.println("-Compression-");
                CompressZip compressZip = new CompressZip();

                if (!compressZip.compress(toZipPath, unZipPath, unZipFile, type)) {
                    System.out.println("Compression failed");
                }
                else{
                    System.out.println(yesterday + "\tCompression success");
                    Delete(yesterday);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            System.out.println("Folder does not exist");
        }

    }

    public void writeDataToCsv(String sensorName, List<Float> Data) throws IOException {

        String NOW_DATE = get_NOW_DATE();

        String mkdir_PATH = "/storage/self/primary/Download/KNIH/KNIH_" + NOW_DATE;
        File dir = new File(mkdir_PATH);
        try {
            if (!dir.exists()) {
                dir.mkdirs();
            }

        }catch (Exception e) {
            e.printStackTrace();
        }

        String Data_new = Data.stream().map(Object::toString).collect(Collectors.joining(","));
        String filePath = "/storage/self/primary/Download/KNIH/KNIH_" + NOW_DATE + "/" + NOW_DATE + "_" + sensorName + ".csv";
        java.io.File file = new java.io.File(filePath);

        CSVWriter writer = new CSVWriter(new FileWriter(file, true));
        String[] entries = Data_new.split(",");

        String NEWLINE = System.lineSeparator();
        entries = ArrayUtils.add(entries,NEWLINE);

        writer.writeNext(entries);

        writer.close();
    }

    // Add a date format to the csv file name
    long mNow;
    Date mDate;
    @SuppressLint("SimpleDateFormat")
    SimpleDateFormat mFormat = new SimpleDateFormat("yyMMdd");
    private String get_NOW_DATE(){
        mNow = System.currentTimeMillis();
        mDate = new Date(mNow);
        return mFormat.format(mDate);
    }

    //Mobile/android functions to upload data to mobius or IoT server

    public void upload_to_mobius_phone_mAcc(String S_name, String Data) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        MediaType mediaType = MediaType.parse("application/vnd.onem2m-res+json; ty=4");
        RequestBody body1 = RequestBody.create(mediaType, "{\n    \"m2m:cin\": {\n        \"con\": \"" + Data + "\"\n    }\n}");


        Request request1 = new Request.Builder()
                .url("http://114.71.220.59:7579/Mobius/"+SID+"/mobile/"+S_name)
                .method("POST", body1)
                .addHeader("Accept", "application/json")
                .addHeader("X-M2M-RI", "12345")
                .addHeader("X-M2M-Origin", ACP)
                .addHeader("Content-Type", "application/vnd.onem2m-res+json; ty=4")
                .build();

        Call call = client.newCall(request1);
        Response response = call.execute();
        Integer responseData1 = 0;
        responseData1 = response.code();
        if (responseData1 != 201 && M_Accerelometer && !Data.contains("None")){
            //write to csv if mobius failed
            //cornerting string to list float for csv
            String[] results;
            results = Data.split(",");

            List<Float> convertedAcc = new ArrayList<>();

            for (int j = 0; j < results.length; j++) {
                float wewe = Float.parseFloat(results[j]);
                convertedAcc.add(wewe);
            }

            // preparing one sec data
            int initialIndex = 0;
            int finalIndex = 32;
            for (int k = 0; k < convertedAcc.size()/32; k++) {
                List<Float> arrlist3 = convertedAcc.subList(initialIndex, finalIndex);
                try {
                    writeDataToCsv("Phone_Acc", arrlist3);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
        if (responseData1 == 201){
            float timestamp = System.currentTimeMillis() / 1000L;
            List<Float> Logdata = new ArrayList<>();
            Logdata.addAll(Collections.singletonList((float) responseData1));
            Logdata.addAll(Collections.singleton(timestamp));
            try {
                writeDataToCsv("PAcc_Log", Logdata);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Log.d("TEST", "ACC RESPONSE MESSAGE : " + responseData1);

    }
    public void upload_to_mobius_phone_mGyr(String S_name, String Data) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        MediaType mediaType = MediaType.parse("application/vnd.onem2m-res+json; ty=4");
        RequestBody body1 = RequestBody.create(mediaType, "{\n    \"m2m:cin\": {\n        \"con\": \"" + Data + "\"\n    }\n}");


        Request request1 = new Request.Builder()
                .url("http://114.71.220.59:7579/Mobius/"+SID+"/mobile/"+ S_name)
                .method("POST", body1)
                .addHeader("Accept", "application/json")
                .addHeader("X-M2M-RI", "12345")
                .addHeader("X-M2M-Origin", ACP)
                .addHeader("Content-Type", "application/vnd.onem2m-res+json; ty=4")
                .build();

        Call call = client.newCall(request1);
        Response response = call.execute();
        Integer responseData1 = 0;
        responseData1 = response.code();
        if (responseData1 != 201 && M_Gyroscope & !Data.contains("None")){

            //cornerting string to list float for csv
            String[] results;
            results = Data.split(",");

            List<Float> convertedGyro = new ArrayList<>();

            for (int j = 0; j < results.length; j++) {
                float wewe = Float.parseFloat(results[j]);
                convertedGyro.add(wewe);
            }

            // preparing one sec data
            int initialIndex = 0;
            int finalIndex = 32;
            for (int k = 0; k < convertedGyro.size()/32; k++) {
                List<Float> arrlist3 = convertedGyro.subList(initialIndex, finalIndex);
                try {
                    writeDataToCsv("Phone_Gyro", arrlist3);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


        }
        if (responseData1 == 201){
            float timestamp = System.currentTimeMillis() / 1000L;
            List<Float> Logdata = new ArrayList<>();
            Logdata.addAll(Collections.singletonList((float) responseData1));
            Logdata.addAll(Collections.singleton(timestamp));
            try {
                writeDataToCsv("PGyro_Log", Logdata);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Log.d("TEST", "GYRO RESPONSE MESSAGE : " + responseData1);


    }
    public void upload_to_mobius_phone_mPre(String S_name, String Data) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        MediaType mediaType = MediaType.parse("application/vnd.onem2m-res+json; ty=4");
        RequestBody body1 = RequestBody.create(mediaType, "{\n    \"m2m:cin\": {\n        \"con\": \"" + Data + "\"\n    }\n}");


        Request request1 = new Request.Builder()
                .url("http://114.71.220.59:7579/Mobius/"+SID+"/mobile/"+S_name)
                .method("POST", body1)
                .addHeader("Accept", "application/json")
                .addHeader("X-M2M-RI", "12345")
                .addHeader("X-M2M-Origin", ACP)
                .addHeader("Content-Type", "application/vnd.onem2m-res+json; ty=4")
                .build();


        Call call = client.newCall(request1);
        Response response = call.execute();
        Integer responseData1 = 0;
        responseData1 = response.code();
        if (responseData1 != 201 && M_pressure & !Data.contains("None")){
            //cornerting string to list float for csv
            String[] results;
            results = Data.split(",");

            List<Float> convertedPre = new ArrayList<>();

            for (int j = 0; j < results.length; j++) {
                float wewe = Float.parseFloat(results[j]);
                convertedPre.add(wewe);
            }

            // preparing one sec data
            int initialIndex = 0;
            int finalIndex = 3;
            for (int k = 0; k < convertedPre.size()/3; k++) {
                List<Float> arrlist3 = convertedPre.subList(initialIndex, finalIndex);
                try {
                    writeDataToCsv("Phone_Pre", arrlist3);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
        if (responseData1 == 201){
            float timestamp = System.currentTimeMillis() / 1000L;
            List<Float> Logdata = new ArrayList<>();
            Logdata.addAll(Collections.singletonList((float) responseData1));
            Logdata.addAll(Collections.singleton(timestamp));
            try {
                writeDataToCsv("PPre_Log", Logdata);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Log.d("TEST", "PRE RESPONSE MESSAGE : " + responseData1);


    }
    public void upload_to_mobius_phone_mLi(String S_name, String Data) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        MediaType mediaType = MediaType.parse("application/vnd.onem2m-res+json; ty=4");
        RequestBody body1 = RequestBody.create(mediaType, "{\n    \"m2m:cin\": {\n        \"con\": \"" + Data + "\"\n    }\n}");


        Request request1 = new Request.Builder()
                .url("http://114.71.220.59:7579/Mobius/"+SID+"/mobile/"+S_name)
                .method("POST", body1)
                .addHeader("Accept", "application/json")
                .addHeader("X-M2M-RI", "12345")
                .addHeader("X-M2M-Origin", ACP)
                .addHeader("Content-Type", "application/vnd.onem2m-res+json; ty=4")
                .build();


        //client.newCall(request1).enqueue(upload_to_mobiusCallback_mLi);
        Call call = client.newCall(request1);
        Response response = call.execute();
        int responseData1 = 0;
        responseData1 = response.code();
        if (responseData1 != 201 && M_Light & !Data.contains("None")){

            //cornerting string to list float for csv
            String[] results;
            results = Data.split(",");

            List<Float> convertedLi = new ArrayList<>();

            for (int j = 0; j < results.length; j++) {
                float wewe = Float.parseFloat(results[j]);
                convertedLi.add(wewe);
            }

            // preparing one sec data
            int initialIndex = 0;
            int finalIndex = 3;
            for (int k = 0; k < convertedLi.size()/3; k++) {
                List<Float> arrlist3 = convertedLi.subList(initialIndex, finalIndex);
                try {
                    writeDataToCsv("Phone_Light", arrlist3);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
        if (responseData1 == 201){
            float timestamp = System.currentTimeMillis() / 1000L;
            List<Float> Logdata = new ArrayList<>();
            Logdata.addAll(Collections.singletonList((float) responseData1));
            Logdata.addAll(Collections.singleton(timestamp));
            try {
                writeDataToCsv("PLight_Log", Logdata);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Log.d("TEST", "LIGHT RESPONSE MESSAGE : " + responseData1);

    }

    @Override
    //Function that listening data from watch/wearable device through datamap API
    public void onDataChanged(DataEventBuffer dataEventBuffer) {
        for(DataEvent event : dataEventBuffer){
            if(event.getType() == DataEvent.TYPE_CHANGED){
                DataItem item = event.getDataItem();
                if(item.getUri().getPath().compareTo("/Acce")==0){
                    DataMap dataMap = DataMapItem.fromDataItem(item).getDataMap();
                    dataMap.getString("Accerelometer");
                    s_acc.add(dataMap.getString("Accerelometer"));

                }
                else if(item.getUri().getPath().compareTo("/Gyro")==0){
                    DataMap dataMap = DataMapItem.fromDataItem(item).getDataMap();
                    dataMap.getString("gyro");
                    s_gyro.add(dataMap.getString("gyro"));

                }
                else if(item.getUri().getPath().compareTo("/HearRate")==0){
                    DataMap dataMap = DataMapItem.fromDataItem(item).getDataMap();
                    dataMap.getString("Hr");
                    s_hr.add(dataMap.getString("Hr"));
                }
                else if(item.getUri().getPath().compareTo("/Press")==0){
                    DataMap dataMap = DataMapItem.fromDataItem(item).getDataMap();
                    dataMap.getString("pressure");
                    s_pre.add(dataMap.getString("pressure"));

                }
            }
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        Wearable.DataApi.addListener(googleApiClient,this);
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        List<Float> SensorDataAcc = new ArrayList<>();
        List<Float> SensorDatagyro = new ArrayList<>();
        List<Float> SensorDatapress = new ArrayList<>();
        List<Float> SensorDatalIGHT = new ArrayList<>();
        int SysTime = (int) (System.currentTimeMillis()/100000L)*100;// 1000000000L;

        Sensor sensor = sensorEvent.sensor;

        float timestamp;
        if(sensor.getType() == Sensor.TYPE_ACCELEROMETER){

            timestamp = sensorEvent.timestamp;
            final int dT = (int) (timestamp * NS2S);

            float X = Math.round(sensorEvent.values[0] * 1000.0f) / 1000.0f;
            float Y = Math.round(sensorEvent.values[1] * 1000.0f) / 1000.0f;
            float Z = Math.round(sensorEvent.values[2] * 1000.0f) / 1000.0f;


            if(accTimeManager != dT){
                int newT = (SysTime+(dT % 100));
                SensorDataAcc.add((float) (newT / 1000000L));
                SensorDataAcc.add((float) (newT % 1000000));
                accTimeManager = dT;
                if(PH_acc_csv.size()== 32){
                    PH_acc.addAll(PH_acc_csv);
                }
                PH_acc_csv.clear();
            }

            SensorDataAcc.add(X);
            SensorDataAcc.add(Y);
            SensorDataAcc.add(Z);

            if(PH_acc_csv.size()<32) {
                PH_acc_csv.addAll(SensorDataAcc);
            }

        }
        else if(sensor.getType() == Sensor.TYPE_GYROSCOPE){
            timestamp = sensorEvent.timestamp;
            final int dT = (int) (timestamp * NS2S);

            float X = Math.round(sensorEvent.values[0] * 1000.0f) / 1000.0f;
            float Y = Math.round(sensorEvent.values[1] * 1000.0f) / 1000.0f;
            float Z = Math.round(sensorEvent.values[2] * 1000.0f) / 1000.0f;

            if(gyroTimeManager != dT){
                int newT = (SysTime+(dT % 100));
                SensorDatagyro.add((float) (newT / 1000000L));
                SensorDatagyro.add((float) (newT % 1000000));
                gyroTimeManager = dT;
                if(PH_gyro_csv.size()== 32){
                    PH_gyro.addAll(PH_gyro_csv);
                }
                PH_gyro_csv.clear();
            }
            SensorDatagyro.add(X);
            SensorDatagyro.add(Y);
            SensorDatagyro.add(Z);

            if(PH_gyro_csv.size()<32) {
                PH_gyro_csv.addAll(SensorDatagyro);
            }

        }
        else if(sensor.getType() == Sensor.TYPE_PRESSURE){
            timestamp = sensorEvent.timestamp;
            final int dT = (int) (timestamp * NS2S);
            float X = Math.round(sensorEvent.values[0] * 100.0f) / 100.0f;
            if(preTimeManager != dT){
                int newT = (SysTime+(dT % 100));
                SensorDatapress.add((float) (newT / 1000000L));
                SensorDatapress.add((float) (newT % 1000000));
                preTimeManager = dT;
                if(PH_pre_csv.size()== 3){
                    PH_pre.addAll(PH_pre_csv);
                }
                PH_pre_csv.clear();
            }
            SensorDatapress.add(X);

            if(PH_pre_csv.size()<3) {
                PH_pre_csv.addAll(SensorDatapress);
            }
        }
        else if(sensor.getType() == Sensor.TYPE_LIGHT){
            timestamp = sensorEvent.timestamp;
            final int dT = (int) (timestamp * NS2S);
            float X = Math.round(sensorEvent.values[0] * 100.0f) / 100.0f;
            if(lightTimeManager != dT){
                int newT = (SysTime+(dT % 100));
                SensorDatalIGHT.add((float) (newT / 1000000L));
                SensorDatalIGHT.add((float) (newT % 1000000));
                lightTimeManager = dT;
                if(PH_Light_csv.size()== 3){
                    PH_Light.addAll(PH_Light_csv);
                }
                PH_Light_csv.clear();
            }

            SensorDatalIGHT.add(X);

            if(PH_Light_csv.size()<3) {
                PH_Light_csv.addAll(SensorDatalIGHT);
            }

        }

    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void SendMobius30() throws IOException {
        if(isConnected()) {
        String NoData = "None";

        //ANDROID OR MOBILE PHONE SENSORS

        // ACC

            if(PH_acc.size() == 0 ) upload_to_mobius_phone_mAcc("mAcc ", NoData);
            if(PH_acc.size() > 0){
                StringJoiner joiner = new StringJoiner(",");
                //updated Float list to string
                for (int i = 0; i < PH_acc.size(); i++) {
                    String toString = PH_acc.get(i).toString();
                    joiner.add(toString);
                }
                String Acc_Mob = joiner.toString();

                upload_to_mobius_phone_mAcc("mAcc ", Acc_Mob);
                PH_acc.clear();
            }

        //gyr

            if(PH_gyro.size() == 0 ) upload_to_mobius_phone_mGyr("mGyr", NoData);
            if(PH_gyro.size() > 0){
                StringJoiner joiner = new StringJoiner(",");
                for (int i = 0; i < PH_gyro.size(); i++) {
                    String toString = PH_gyro.get(i).toString();
                    joiner.add(toString);
                }
                String Gyro_Mob = joiner.toString();
                upload_to_mobius_phone_mGyr("mGyr", Gyro_Mob);
                PH_gyro.clear();
            }

        //Pre


            if(PH_pre.size() == 0 ) upload_to_mobius_phone_mPre("mPre", NoData);
            if(PH_pre.size() > 0){
                StringJoiner joiner = new StringJoiner(",");
                for (int i = 0; i < PH_pre.size(); i++) {
                    String toString = PH_pre.get(i).toString();
                    joiner.add(toString);
                }
                String Pre_Mob = joiner.toString();
                upload_to_mobius_phone_mPre("mPre", Pre_Mob);
                PH_pre.clear();
            }

        //Light

            if(PH_Light.size() == 0 ) upload_to_mobius_phone_mLi("mLi", NoData);
            if(PH_Light.size() > 0){
                StringJoiner joiner = new StringJoiner(",");
                for (int i = 0; i < PH_Light.size(); i++) {
                    String toString = PH_Light.get(i).toString();
                    joiner.add(toString);
                }
                String Li_Mob = joiner.toString();
                upload_to_mobius_phone_mLi("mLi", Li_Mob);
                PH_Light.clear();
            }

        //WATCH SENSORS

        //Acc

            if(s_acc.size() == 0 ) upload_to_mobius_watch_wAcc("wAcc", NoData);
            if(s_acc.size() > 0){
                List<String> Acc_Temp = new ArrayList<>();
                s_acc.forEach((data) -> {
                    Acc_Temp.addAll(Collections.singleton(data));
                });
                String Acc_Temp1 = String.join(", ", Acc_Temp);
                upload_to_mobius_watch_wAcc("wAcc", Acc_Temp1);
                s_acc.clear();
            }

        //Gyr_watch

            if(s_gyro.size() == 0 ) upload_to_mobius_watch_wGyr("wGyr", NoData);
            if(s_gyro.size() > 0){
                List<String> Acc_Temp = new ArrayList<>();
                s_gyro.forEach((data) -> {
                    Acc_Temp.addAll(Collections.singleton(data));
                });
                String Acc_Temp1 = String.join(", ", Acc_Temp);
                upload_to_mobius_watch_wGyr("wGyr",Acc_Temp1);
                s_gyro.clear();
            }

        //HR_watch

            if(s_hr.size() == 0 ) upload_to_mobius_watch_wHR("wHR", NoData);
            if(s_hr.size() > 0){
                List<String> Acc_Temp = new ArrayList<>();
                s_hr.forEach((data6) -> {
                    Acc_Temp.addAll(Collections.singleton(data6));
                });
                String HR_Temp1 = String.join(", ", Acc_Temp);
                upload_to_mobius_watch_wHR("wHR",HR_Temp1);
                s_hr.clear();
            }

        //PRE watch

            if(s_pre.size() == 0 ) upload_to_mobius_watch_wPre("wPre", NoData);
            if(s_pre.size() > 0){
                List<String> Acc_Temp = new ArrayList<>();
                s_pre.forEach((data6) -> {
                    Acc_Temp.addAll(Collections.singleton(data6));
                });
                String HR_Temp1 = String.join(", ", Acc_Temp);
                upload_to_mobius_watch_wPre("wPre",HR_Temp1);
                s_pre.clear();
            }
        }
        else{
            // if not connected and buffer has some data

            if(PH_acc.size()>0) {
                StringJoiner joiner = new StringJoiner(",");
                for (int i = 0; i < PH_acc.size(); i++) {
                    String toString = PH_acc.get(i).toString();
                    joiner.add(toString);
                }
                String Acc_Mob = joiner.toString();
                Mobius_PH_acc.add(Acc_Mob);
                PH_acc.clear();
                System.out.println("SAVE BUFFER ACC " + Mobius_PH_acc.size());
            }

            if(PH_gyro.size()>0) {
                StringJoiner joiner = new StringJoiner(",");
                for (int i = 0; i < PH_gyro.size(); i++) {
                    String toString = PH_gyro.get(i).toString();
                    joiner.add(toString);
                }
                String Gyro_Mob = joiner.toString();
                Mobius_PH_gyro.add(Gyro_Mob);
                PH_gyro.clear();
                System.out.println("SAVE BUFFER GYRO " + Mobius_PH_gyro.size());
            }

            if(PH_pre.size()>0) {
                StringJoiner joiner = new StringJoiner(",");
                for (int i = 0; i < PH_pre.size(); i++) {
                    String toString = PH_pre.get(i).toString();
                    joiner.add(toString);
                }
                String Pre_Mob = joiner.toString();
                Mobius_PH_pre.add(Pre_Mob);
                PH_pre.clear();
                System.out.println("SAVE BUFFER PRE " + Mobius_PH_pre.size());
            }

            if(PH_Light.size()>0) {
                StringJoiner joiner = new StringJoiner(",");
                for (int i = 0; i < PH_Light.size(); i++) {
                    String toString = PH_Light.get(i).toString();
                    joiner.add(toString);
                }
                String Li_Mob = joiner.toString();
                Mobius_PH_Light.add(Li_Mob);
                PH_Light.clear();
                System.out.println("SAVE BUFFER LIGHT " + Mobius_PH_Light.size());
            }

            if(s_acc.size()>0) {
                List<String> Acc_Temp = new ArrayList<>();
                s_acc.forEach((data) -> {
                    Acc_Temp.addAll(Collections.singleton(data));
                });
                String Acc_Temp1 = String.join(", ", Acc_Temp);
                Mobius_wPH_acc.add(Acc_Temp1);
                s_acc.clear();
                System.out.println("SAVE BUFFER watch LIGHT " + Mobius_wPH_acc.size());
            }

            if(s_gyro.size()>0) {
                List<String> Gyro_Temp = new ArrayList<>();
                s_gyro.forEach((data) -> {
                    Gyro_Temp.addAll(Collections.singleton(data));
                });
                String Acc_Temp1 = String.join(", ", Gyro_Temp);
                Mobius_wPH_gyro.add(Acc_Temp1);
                s_gyro.clear();
                System.out.println("SAVE BUFFER watch Gyro " + Mobius_wPH_gyro.size());
            }

            if(s_hr.size()>0) {
                List<String> Hr_Temp = new ArrayList<>();
                s_hr.forEach((data) -> {
                    Hr_Temp.addAll(Collections.singleton(data));
                });
                String Acc_Temp1 = String.join(", ", Hr_Temp);
                Mobius_wPH_Hr.add(Acc_Temp1);
                s_hr.clear();
                System.out.println("SAVE BUFFER watch Hr " + Mobius_wPH_Hr.size());
            }

            if(s_pre.size()>0) {
                List<String> Pre_Temp = new ArrayList<>();
                s_pre.forEach((data) -> {
                    Pre_Temp.addAll(Collections.singleton(data));
                });
                String Acc_Temp1 = String.join(", ", Pre_Temp);
                Mobius_wPH_pre.add(Acc_Temp1);
                s_pre.clear();
                System.out.println("SAVE BUFFER watch Pre " + Mobius_wPH_pre.size());
            }

        // if not connected and buffer is empty

            if(PH_acc.size()==0) {
                String Acc_Mob = "None";
                Mobius_PH_acc.add(Acc_Mob);
                System.out.println("SAVE BUFFER ACC " + Mobius_PH_acc.size());
            }

            if(PH_gyro.size()==0) {
                String Gyro_Mob = "None";
                Mobius_PH_gyro.add(Gyro_Mob);
                System.out.println("SAVE BUFFER GYRO " + Mobius_PH_gyro.size());
            }

            if(PH_pre.size()==0) {
                String Pre_Mob = "None";
                Mobius_PH_pre.add(Pre_Mob);
                System.out.println("SAVE BUFFER PRE " + Mobius_PH_pre.size());
            }

            if(PH_Light.size()==0) {
                String Li_Mob = "None";
                Mobius_PH_Light.add(Li_Mob);
                System.out.println("SAVE BUFFER LIGHT " + Mobius_PH_Light.size());
            }

            if(s_acc.size()==0) {
                String w_acc = "None";
                Mobius_wPH_acc.add(w_acc);
                System.out.println("SAVE BUFFER watch LIGHT " + Mobius_wPH_acc.size());
            }

            if(s_gyro.size()==0) {
                String w_gyro = "None";
                Mobius_wPH_gyro.add(w_gyro);
                System.out.println("SAVE BUFFER watch Gyro " + Mobius_wPH_gyro.size());
            }

            if(s_hr.size()==0) {
                String w_hr = "None";
                Mobius_wPH_Hr.add(w_hr);
                System.out.println("SAVE BUFFER watch Hr " + Mobius_wPH_Hr.size());
            }

            if(s_pre.size()==0) {
                String w_pre = "None";
                Mobius_wPH_pre.add(w_pre);
                System.out.println("SAVE BUFFER watch Pre " + Mobius_wPH_pre.size());
            }
        }

    }

    public void SendStoredBufferWhenConnected(){

        if(isConnected()) {
            // mobile stored buffer
            if (Mobius_PH_acc.size() > 0) {
                Mobius_PH_acc.forEach((data1) -> {
                    if(data1.length()>30 ) {
                        try {
                            upload_to_mobius_phone_mAcc("mAcc", data1);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                // Clearing Phone buffer
                Mobius_PH_acc.clear();
            }
            if (Mobius_PH_gyro.size() > 0) {
                Mobius_PH_gyro.forEach((data2) -> {
                    if(data2.length()> 30 ) {
                        try {
                            upload_to_mobius_phone_mGyr("mGyr", data2);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                // Clearing Phone buffer
                Mobius_PH_gyro.clear();
            }
            if (Mobius_PH_pre.size() > 0) {
                Mobius_PH_pre.forEach((data3) -> {
                    if(data3.length()> 30 ) {
                        try {
                            upload_to_mobius_phone_mPre("mPre", data3);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                // Clearing Phone buffer
                Mobius_PH_pre.clear();
            }
            if (Mobius_PH_Light.size() > 0) {
                Mobius_PH_Light.forEach((data4) -> {
                    if(data4.length()> 30 ) {
                        try {
                            upload_to_mobius_phone_mLi("mLi", data4);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                // Clearing Phone buffer
                Mobius_PH_Light.clear();
            }

            //Watch stored buffer
            if (Mobius_wPH_acc.size() > 0) {
                Mobius_wPH_acc.forEach((data7) -> {
                    if(data7.length()> 30 ) {
                        try {
                            upload_to_mobius_watch_wAcc("wAcc", data7);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                // Clearing watch buffer
                Mobius_wPH_acc.clear();
            }
            if (Mobius_wPH_gyro.size() > 0) {
                Mobius_wPH_gyro.forEach((data5) -> {
                    if(data5.length()> 30 ) {
                        try {
                            upload_to_mobius_watch_wGyr("wGyr", data5);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                // Clearing watch buffer
                Mobius_wPH_gyro.clear();
            }
            if (Mobius_wPH_Hr.size() > 0) {
                Mobius_wPH_Hr.forEach((data6) -> {
                    if(data6.length()> 30 ) {
                        try {
                            upload_to_mobius_watch_wHR("wHR", data6);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                // Clearing watch buffer
                Mobius_wPH_Hr.clear();
            }
            if (Mobius_wPH_pre.size() > 0) {
                Mobius_wPH_pre.forEach((data8) -> {
                    if(data8.length()> 30 ) {
                        try {
                            upload_to_mobius_watch_wPre("wPre", data8);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                // Clearing watch buffer
                Mobius_wPH_pre.clear();
            }
        }
    }

    boolean isConnected(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if(networkInfo != null){
            return networkInfo.isConnected();
        }
        else
            return false;
    }
    // 5 minutes
    // 15 minutes....


    private void callTimer1(){
        final Timer myTimer = new Timer();
        myTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                SendStoredBufferWhenConnected();
            }
        }, 0,2000);
    }
}

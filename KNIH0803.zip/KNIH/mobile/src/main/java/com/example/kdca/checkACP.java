package com.example.kdca;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class checkACP {

    public static boolean check(String SID, String ACP) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        MediaType mediaType = MediaType.parse("text/plain");

        Request request = new Request.Builder()
                .url("http://114.71.220.59:7579/Mobius/"+SID)
//                .url("http://114.71.220.59:7579/Mobius/S606")
//                .url("http://203.253.128.161:7579/Mobius/S300")
//                .url("http://203.253.128.161:7579/Mobius/"+"S"+SID)
                .method("GET", null)
                .addHeader("Accept", "application/json")
                .addHeader("X-M2M-RI", "12345")
                .addHeader("X-M2M-Origin", ACP)
                .build();

        Response response = client.newCall(request).execute();

        Integer responseData = 0;
        responseData = response.code();

        System.out.println("\t["+response+"]");

        if (responseData == 200) {
//            System.out.println("ACP Authentication successful");
            return true;
        }
        else {
//            System.out.println("ACP Authentication failed");
            response.close();
            return false;
        }
    }
}

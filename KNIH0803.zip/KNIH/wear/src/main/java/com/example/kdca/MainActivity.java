package com.example.kdca;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;

import com.example.kdca.databinding.ActivityMainBinding;

@SuppressWarnings("ALL")
public class MainActivity extends Activity {

    private final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STROAGE = 1001;
    private PermissionSupport permission;
    static final int ALARM_REQ_CODE = 100;

    private ActivityMainBinding binding;
    private static final String TAG = "MainActivity";


    private static PowerManager.WakeLock wakeLock = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(!foregroundServiceRunning()) {
            Intent serviceIntent = new Intent(this, MyForegroundService.class);
            startForegroundService(serviceIntent);

        }
        AlarmManager alarmManager =(AlarmManager) getSystemService(ALARM_SERVICE);

        int time = 1;
        long triggerTime = System.currentTimeMillis()+ (time*1000);

        Intent iBroadCast = new Intent(MainActivity.this,MyAlarm.class);
        PendingIntent pi = null;
        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.S){
            pi = PendingIntent.getBroadcast(MainActivity.this,ALARM_REQ_CODE,iBroadCast,PendingIntent.FLAG_MUTABLE);
        }else {
            pi = PendingIntent.getBroadcast(MainActivity.this,ALARM_REQ_CODE,iBroadCast,PendingIntent.FLAG_UPDATE_CURRENT);
        }

        //alarmManager.set(AlarmManager.RTC_WAKEUP,triggerTime,pi);
        //setting the repeating alarm that will be fired every day
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, triggerTime, 3000, pi);

        permissionCheck();

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "DoNotDimScreen");

        wakeLock.acquire();

    }

    public boolean foregroundServiceRunning(){
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for(ActivityManager.RunningServiceInfo service: activityManager.getRunningServices(Integer.MAX_VALUE)) {
            if(MyForegroundService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }


    private void permissionCheck(){
        // sdk 23버전 이하 버전에서는 permission이 필요하지 않음
        if(Build.VERSION.SDK_INT >= 23){

            // 클래스 객체 생성
            permission =  new PermissionSupport(this, this);

            // 권한 체크한 후에 리턴이 false일 경우 권한 요청을 해준다.
            if(!permission.checkPermission()){
                permission.requestPermission();
            }
        }
    }


}
package com.example.kdca;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.wearable.DataApi;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;

import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public class MyForegroundService extends Service implements DataApi.DataListener, GoogleApiClient.ConnectionCallbacks,GoogleApiClient.OnConnectionFailedListener,SensorEventListener {

    private static final float NS2S = 1.0f / 1000000000.0f;

    GoogleApiClient googleApiClient;
    List<Float> s_acc = new ArrayList<>();
    List<Float> s_gyro = new ArrayList<>();
    List<Float> s_pre = new ArrayList<>();
    List<Float> s_hr = new ArrayList<>();


    // for send to phone
    List<Float> PH_acc_send = new ArrayList<>();
    List<Float> PH_gyro_send = new ArrayList<>();
    List<Float> PH_pre_send = new ArrayList<>();
    List<Float> PH_hr_send = new ArrayList<>();

    int accTimeManager = 0;
    int gyroTimeManager = 0;
    int preTimeManager = 0;
    int hrTimeManager = 0;


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        googleApiClient = new GoogleApiClient.Builder(this)
                .addApi(Wearable.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();
        googleApiClient.connect();

        SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);


        //AFE4500S ECG,Samsung HR Raw Sensor,Samsung HR Raw Fac Sensor,Samsung HR None Wakeup Sensor,Samsung HR Sensor
        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null){
            sensorManager.registerListener(MyForegroundService.this, accelerometer, 100000);
        }

        Sensor mGyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if (mGyro != null){
            sensorManager.registerListener(MyForegroundService.this, mGyro, 100000);
        }


        Sensor mPressure = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);
        if (mPressure != null){
            sensorManager.registerListener(MyForegroundService.this, mPressure, 100000);
        }


        Sensor mHeart = sensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE);
        if (mHeart != null){
            sensorManager.registerListener(MyForegroundService.this, mHeart, 100000);
        }

        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        while (true) {
                            //onCreate();
                            Log.e("Service", "Service is running...");
                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
        ).start();

        final String CHANNELID = "Foreground Service ID";
        NotificationChannel channel = new NotificationChannel(
                CHANNELID, 
                CHANNELID, 
                NotificationManager.IMPORTANCE_LOW );

        getSystemService(NotificationManager.class).createNotificationChannel(channel);
        Notification.Builder notification = new Notification.Builder(this, CHANNELID)
                .setContentText("Service is running")
                .setContentTitle("Service enabled")
                .setSmallIcon(R.drawable.ic_launcher_background);

        //startForeground(1001, notification.build());
        startForeground(1001, notification.build());

        return super.onStartCommand(intent, flags, startId);


    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        List<Float> SensorDataAcc = new ArrayList<>();
        List<Float> SensorDatagyro = new ArrayList<>();
        List<Float> SensorDatapress = new ArrayList<>();
        List<Float> SensorDataHrt = new ArrayList<>();
        Integer timeTosend = 240;//nter time in seconds
        int SysTime = (int) (System.currentTimeMillis()/100000L)*100;// 1000000000L;

        float timestamp;
        if(sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER){

            timestamp = sensorEvent.timestamp;
            final int dT = (int) (timestamp * NS2S);

            float X = Math.round(sensorEvent.values[0] * 1000.0f) / 1000.0f;
            float Y = Math.round(sensorEvent.values[1] * 1000.0f) / 1000.0f;
            float Z = Math.round(sensorEvent.values[2] * 1000.0f) / 1000.0f;

            if(accTimeManager != dT){
                int newT = (SysTime+(dT % 100));
                SensorDataAcc.add((float) (newT / 1000000L));
                SensorDataAcc.add((float) (newT % 1000000));
                accTimeManager = dT;
                if(PH_acc_send.size()== 32){
                    s_acc.addAll(PH_acc_send);
                }
                PH_acc_send.clear();
            }

            SensorDataAcc.add(X);
            SensorDataAcc.add(Y);
            SensorDataAcc.add(Z);

//            s_acc.addAll(SensorDataAcc);
//            System.out.println("THIS IS ACC DATA" + s_acc.size());
            if(PH_acc_send.size()<=32) {
                PH_acc_send.addAll(SensorDataAcc);
            }


            // Here we can set time or (collecting data for 30 min and check length, and start to share to android) way for share data to android device
            /// waiting time 50sec
            if(s_acc.size() >= (32*timeTosend)){
                int fromIndex = 0;
                int toIndex = 32*timeTosend;
//                System.out.println("BEFORE" + s_acc.size());
                // getting the subList
                // using subList() method
                List<Float> arrlist2 = s_acc.subList(fromIndex, toIndex);
                ShareDataAcc(arrlist2);

                s_acc.subList(fromIndex, toIndex).clear();

            }
            // end share data to android device

        }
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_GYROSCOPE){
            timestamp = sensorEvent.timestamp;
            final int dT = (int) (timestamp * NS2S);

            float X = Math.round(sensorEvent.values[0] * 1000.0f) / 1000.0f;
            float Y = Math.round(sensorEvent.values[1] * 1000.0f) / 1000.0f;
            float Z = Math.round(sensorEvent.values[2] * 1000.0f) / 1000.0f;

            if(gyroTimeManager != dT){
                int newT = (SysTime+(dT % 100));
                SensorDatagyro.add((float) (newT / 1000000L));
                SensorDatagyro.add((float) (newT % 1000000));
                gyroTimeManager = dT;
                if(PH_gyro_send.size()== 32){
                    s_gyro.addAll(PH_gyro_send);
                }
                PH_gyro_send.clear();
            }
            SensorDatagyro.add(X);
            SensorDatagyro.add(Y);
            SensorDatagyro.add(Z);

//            s_gyro.addAll(SensorDatagyro);
//            System.out.println("THIS IS GYRO DATA" + s_gyro);
            if(PH_gyro_send.size()<32) {
                PH_gyro_send.addAll(SensorDatagyro);
            }


            // Here we can set time or (collecting data for 30 min and check length, and start to share to android) way for share data to android device
            /// waiting time 50sec
            if(s_gyro.size() > (32*timeTosend)){
                int fromIndex = 0;
                int toIndex = 32*timeTosend;
                List<Float> arrlist2 = s_gyro.subList(fromIndex, toIndex);
                ShareDataGyro(arrlist2);

                s_gyro.subList(fromIndex, toIndex).clear();
            }
            // end share data to android device

        }
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_PRESSURE){
            timestamp = sensorEvent.timestamp;
            final int dT = (int) (timestamp * NS2S);
            float X = Math.round(sensorEvent.values[0] * 100.0f) / 100.0f;
            if(preTimeManager != dT){
                int newT = (SysTime+(dT % 100));
                SensorDatapress.add((float) (newT / 1000000L));
                SensorDatapress.add((float) (newT % 1000000));
                preTimeManager = dT;
                if(PH_pre_send.size()== 3){
                    s_pre.addAll(PH_pre_send);
                }
//                System.out.println("PRESSURE ISSUE" + s_pre.size());
//                System.out.println("PRESSURE ISSUE" + s_pre);
                PH_pre_send.clear();
            }
            SensorDatapress.add(X);

//            s_pre.addAll(SensorDatapress);
//            System.out.println("THIS IS PRESS DATA" + s_pre);
            if(PH_pre_send.size() < 3) {
                PH_pre_send.addAll(SensorDatapress);
            }

            // Here we can set time or (collecting data for 30 min and check length, and start to share to android) way for share data to android device
            /// waiting time 50sec
            if(s_pre.size() > (3*timeTosend)){

                int fromIndex = 0;
                int toIndex = 3*timeTosend;
                List<Float> arrlist2 = s_pre.subList(fromIndex, toIndex);
                ShareDataPress(arrlist2);

                s_pre.subList(fromIndex, toIndex).clear();
            }
            // end share data to android device

        }
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_HEART_RATE){
            timestamp = sensorEvent.timestamp;
            final int dT = (int) (timestamp * NS2S);
            float X = Math.round(sensorEvent.values[0] * 100.0f) / 100.0f;


            if(hrTimeManager != dT){
                int newT = (SysTime+(dT % 100));
                SensorDataHrt.add((float) (newT / 1000000L));
                SensorDataHrt.add((float) (newT % 1000000));
                hrTimeManager = dT;
                if(PH_hr_send.size()== 3){
                    s_hr.addAll(PH_hr_send);
                }
                System.out.println("HEART RATE ISSUE" + s_hr.size());
                System.out.println("HEART RATE ISSUE" + s_hr);
                PH_hr_send.clear();
            }
            SensorDataHrt.add(X);


//            s_hr.addAll(SensorDataHrt);
//            System.out.println("THIS IS HR DATA" + s_hr);
            if(PH_hr_send.size()< 3) {
                PH_hr_send.addAll(SensorDataHrt);
            }

            // Here we can set time or (collecting data for 30 min and check length, and start to share to android) way for share data to android device
            /// waiting time 50sec
            if(s_hr.size() > (3*timeTosend)){
                int fromIndex = 0;
                int toIndex = 3*timeTosend;
                List<Float> arrlist2 = s_hr.subList(fromIndex, toIndex);
                ShareDataHr(arrlist2);

                s_hr.subList(fromIndex, toIndex).clear();
            }
            // end share data to android device


        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }
    @Override
    public void onConnectionSuspended(int i) {

    }
    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
    @Override
    public void onDataChanged(@NonNull DataEventBuffer dataEventBuffer) {

    }

    public void ShareDataHr(List<Float> DataHr){
            StringJoiner joiner = new StringJoiner(",");
            for (int i = 0; i < DataHr.size(); i++) {
                String toString = DataHr.get(i).toString();
                joiner.add(toString);
            }
            String heartRate = joiner.toString();

            PutDataMapRequest putDataMapRequest = PutDataMapRequest.create("/HearRate");
            putDataMapRequest.getDataMap().putString("Hr",heartRate);
            PutDataRequest putDataRequest = putDataMapRequest.asPutDataRequest();
            Wearable.DataApi.putDataItem(googleApiClient, putDataRequest)
                    .setResultCallback(dataItemResult ->  {
                        if(dataItemResult.getStatus().isSuccess()){
                            System.out.println("HR SUCCESS: ");
                        }
                        else if(dataItemResult.getStatus().isCanceled()){
                            System.out.println("HR CANCELED: ");
                            Wearable.DataApi.putDataItem(googleApiClient, putDataRequest);
                        }
                        else if(dataItemResult.getStatus().isInterrupted()){
                            System.out.println("HR INTERRUPTED: ");
                            Wearable.DataApi.putDataItem(googleApiClient, putDataRequest);
                        }
                    });

    }

    public void ShareDataGyro(List<Float> DataGyro){
        StringJoiner joiner = new StringJoiner(",");
        for (int i = 0; i < DataGyro.size(); i++) {
            String toString = DataGyro.get(i).toString();
            joiner.add(toString);
        }
        String gyro = joiner.toString();

        PutDataMapRequest putDataMapRequest = PutDataMapRequest.create("/Gyro");
        putDataMapRequest.getDataMap().putString("gyro",gyro);
        PutDataRequest putDataRequest = putDataMapRequest.asPutDataRequest();
        Wearable.DataApi.putDataItem(googleApiClient, putDataRequest)
                .setResultCallback(dataItemResult ->  {
                    if(dataItemResult.getStatus().isSuccess()){
                        System.out.println("GY SUCCESS: ");
                    }
                    else if(dataItemResult.getStatus().isCanceled()){
                        System.out.println("GY CANCELED: ");
                        Wearable.DataApi.putDataItem(googleApiClient, putDataRequest);
                    }
                    else if(dataItemResult.getStatus().isInterrupted()){
                        System.out.println("GY INTERRUPTED: ");
                        Wearable.DataApi.putDataItem(googleApiClient, putDataRequest);
                    }
                });
    }

    public void ShareDataAcc(List<Float> DataAcc){

    StringJoiner joiner = new StringJoiner(",");
    for (int i = 0; i < DataAcc.size(); i++) {
        String toString = DataAcc.get(i).toString();
        joiner.add(toString);
    }
    String Acc = joiner.toString();

    System.out.println("I AM INSIDE NOW: " + Acc);
    PutDataMapRequest putDataMapRequest = PutDataMapRequest.create("/Acce");
    putDataMapRequest.getDataMap().putString("Accerelometer", Acc);
    PutDataRequest putDataRequest = putDataMapRequest.asPutDataRequest();
    Wearable.DataApi.putDataItem(googleApiClient, putDataRequest)
            .setResultCallback(dataItemResult ->  {
                if(dataItemResult.getStatus().isSuccess()){
                    System.out.println("ACC SUCCESS: ");
                }
                else if(dataItemResult.getStatus().isCanceled()){
                    System.out.println("ACC CANCELED: ");
                    Wearable.DataApi.putDataItem(googleApiClient, putDataRequest);
                }
                else if(dataItemResult.getStatus().isInterrupted()){
                    System.out.println("ACC INTERRUPTED: ");
                    Wearable.DataApi.putDataItem(googleApiClient, putDataRequest);
                }
            });

    }

    public void ShareDataPress(List<Float> DataPress){
            StringJoiner joiner = new StringJoiner(",");
            for (int i = 0; i < DataPress.size(); i++) {
                String toString = DataPress.get(i).toString();
                joiner.add(toString);
            }
            String press = joiner.toString();

            PutDataMapRequest putDataMapRequest = PutDataMapRequest.create("/Press");
            putDataMapRequest.getDataMap().putString("pressure",press);
            PutDataRequest putDataRequest = putDataMapRequest.asPutDataRequest();
            Wearable.DataApi.putDataItem(googleApiClient, putDataRequest)
                    .setResultCallback(dataItemResult ->  {
                        if(dataItemResult.getStatus().isSuccess()){
                            System.out.println("PRE SUCCESS: ");
                        }
                        else if(dataItemResult.getStatus().isCanceled()){
                            System.out.println("PRE CANCELED: ");
                            Wearable.DataApi.putDataItem(googleApiClient, putDataRequest);
                        }
                        else if(dataItemResult.getStatus().isInterrupted()){
                            System.out.println("PRE INTERRUPTED: ");
                            Wearable.DataApi.putDataItem(googleApiClient, putDataRequest);
                        }
                    });
    }

//    public void ShareAcc(){
//        if(s_acc.size() <= (62*timeTosend) ) {
//            System.out.println("THIS IS ACC: LESS  " + s_acc);
//            ShareDataAcc(s_acc);
//        }
//        else{
//            System.out.println("THIS IS ACC: GREATER  " + s_acc);
//            int fromIndex = 0;
//            int toIndex = 62 * timeTosend;
//            // getting the subList
//            List<Float> arrlist2 = s_acc.subList(fromIndex, toIndex);
//            ShareDataAcc(arrlist2);
//            s_acc.subList(fromIndex, toIndex).clear();
//        }
//    }
//
//    private void callTimer(){
//        final Timer myTimer = new Timer();
//        myTimer.schedule(new TimerTask() {
//            @Override
//            public void run() {
//                ShareAcc();
//                System.out.println("SEND ACC DATA TO PHONE: ");
//            }
//        }, 0,180000);
//    }
}
